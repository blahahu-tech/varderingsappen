"use client";
import { useParams, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { useAuth, useUser } from "@clerk/nextjs";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import type { Entry } from "@/app/layout";

export default function AdminDetail() {
  const params = useParams();
  const router = useRouter();
  const { userId } = useAuth();
  const { user } = useUser();
  const [entry, setEntry] = useState<Entry | null>(null);
  const chartRef = useRef<HTMLDivElement>(null);
  const reportRef = useRef<HTMLDivElement>(null);
  const [toEmail, setToEmail] = useState("");
  const [ccEmail, setCcEmail] = useState("");

  useEffect(() => {
    if (!userId) return;
    const storageKey = `valuationHistory:${userId}`;
    const raw = localStorage.getItem(storageKey);
    if (raw) {
      const list: Entry[] = JSON.parse(raw);
      const idx = Number(params?.id);
      if (!isNaN(idx) && list[idx]) {
        setEntry(list[idx]);
      }
    }
  }, [params, userId]);

  if (!entry) {
    return <div className="p-4">Ingen data hittades.</div>;
  }

  const mockTrend = [
    { year: "2020", value: entry.value * 0.85 },
    { year: "2021", value: entry.value * 0.9 },
    { year: "2022", value: entry.value * 0.95 },
    { year: "2023", value: entry.value },
  ];

  const exportChartPNG = () => {
    if (!chartRef.current) return;
    html2canvas(chartRef.current).then((canvas) => {
      const link = document.createElement("a");
      link.download = `detalj-graf.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();
    });
  };

  const exportReportPNG = () => {
    if (!reportRef.current) return;
    html2canvas(reportRef.current).then((canvas) => {
      const link = document.createElement("a");
      link.download = `renoveringsrapport.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();
    });
  };

  const buildReportPDFBase64 = async () => {
    if (!reportRef.current) return null;
    const canvas = await html2canvas(reportRef.current, { scale: 2 });
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF("p", "mm", "a4");
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
    pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
    return btoa(pdf.output());
  };

  const exportReportPDF = async () => {
    const b64 = await buildReportPDFBase64();
    if (!b64) return;
    const pdf = atob(b64);
    const arr = new Uint8Array(pdf.length);
    for (let i = 0; i < pdf.length; i++) arr[i] = pdf.charCodeAt(i);
    const blob = new Blob([arr], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `renoveringsrapport.pdf`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const sendReportEmail = async (to: string, cc?: string) => {
    const pdfBase64 = await buildReportPDFBase64();
    if (!pdfBase64) return;
    const res = await fetch("/api/send-report", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        to,
        cc: cc || undefined,
        subject: "Renoveringsrapport",
        text: "Hej! Här är renoveringsrapporten som PDF.",
        pdfBase64,
      }),
    });
    if (res.ok) {
      alert("Mejl skickat!");
    } else {
      alert("Det gick inte att skicka mejlet.");
    }
  };

  const sendToMyself = async () => {
    const myEmail = user?.primaryEmailAddress?.emailAddress;
    if (!myEmail) {
      alert("Kunde inte hämta din e-post från kontot.");
      return;
    }
    await sendReportEmail(myEmail);
  };

  return (
    <div className="space-y-6">
      <Button variant="ghost" onClick={() => router.push("/admin")}>
        ← Tillbaka
      </Button>
      <h1 className="text-2xl font-bold">Detaljvy</h1>

      <div ref={reportRef} className="space-y-6">
        <div className="rounded-2xl border p-4 space-y-2">
          <p><strong>Adress:</strong> {entry.address}</p>
          <p><strong>Datum:</strong> {entry.date}</p>
          <p><strong>Värde:</strong> {entry.value.toLocaleString("sv-SE")} kr</p>
        </div>

        <div className="rounded-2xl border p-4">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-lg font-semibold">Trend (simulerad)</h2>
            <button onClick={exportChartPNG} className="text-xs underline">Exportera graf PNG</button>
          </div>
          <div ref={chartRef} className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mockTrend}>
                <XAxis dataKey="year" />
                <YAxis domain={["auto", "auto"]} />
                <Tooltip formatter={(v: number) => `${v.toLocaleString("sv-SE")} kr`} />
                <Line type="monotone" dataKey="value" stroke="#22c55e" strokeWidth={3} dot />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {entry.renovation ? (
          <div className="rounded-2xl border p-4 space-y-2">
            <h2 className="text-lg font-semibold mb-2">Renoveringssimulering</h2>
            <p>🛠 Kostnad: <strong>{entry.renovation.totalCost.toLocaleString("sv-SE")} kr</strong></p>
            <p>📈 Möjlig värdehöjning: <strong>{entry.renovation.estimatedGain.toLocaleString("sv-SE")} kr</strong></p>
            <p>💰 Nettovinst: <strong>{entry.renovation.net.toLocaleString("sv-SE")} kr</strong></p>
            <p>📊 Lönsamhet: <strong>{entry.renovation.roi.toFixed(0)}%</strong></p>
            <p className="text-sm">Åtgärder: {entry.renovation.selected.join(", ") || "Inga"}</p>
            <p className="text-sm">Yta: {entry.renovation.sqm} kvm, Våning: {entry.renovation.floor}, Balkong: {entry.renovation.hasBalcony ? "Ja" : "Nej"}</p>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">Ingen renoveringssimulering sparad.</p>
        )}
      </div>

      <div className="flex flex-col gap-2 max-w-md">
        <div className="flex gap-2 flex-wrap">
          <button onClick={exportReportPNG} className="rounded bg-indigo-600 px-3 py-1 text-white">Exportera hela rapporten PNG</button>
          <button onClick={exportReportPDF} className="rounded bg-red-600 px-3 py-1 text-white">Exportera hela rapporten PDF</button>
        </div>
        <input type="email" value={toEmail} onChange={(e) => setToEmail(e.target.value)} placeholder="Mottagarens e-post" className="rounded border px-2 py-1" />
        <input type="email" value={ccEmail} onChange={(e) => setCcEmail(e.target.value)} placeholder="Kopia till (valfritt)" className="rounded border px-2 py-1" />
        <div className="flex gap-2">
          <button onClick={() => toEmail && sendReportEmail(toEmail, ccEmail)} className="rounded bg-blue-600 px-3 py-1 text-white">Skicka via e-post</button>
          <button onClick={sendToMyself} className="rounded bg-emerald-600 px-3 py-1 text-white">Skicka till mig själv</button>
        </div>
      </div>
    </div>
  );
}